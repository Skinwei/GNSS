%% 码相关器
%% result 相关结果
function [tempchar Channel_Corre] = Code_Correlate(tempComplexData)


end